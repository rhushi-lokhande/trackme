/// <reference path="../../../../typings/tsd.d.ts"/>
interface IClient {
    name: string;
}

export =IClient;