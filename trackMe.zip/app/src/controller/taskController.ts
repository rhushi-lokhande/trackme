/// <reference path="../../../typings/tsd.d.ts"/>
import mongoose = require('mongoose');
let Project = require('../model/project/project');
let Developer = require('../model/developer/developer');
let Task = require('../model/task/task');
import {Request, Response} from "express";

let taskController = {
    newTask: (req: Request, res: Response) => {
        Task.create({
            title: req.body.title,
            description: req.body.description,
            complitionDate: req.body.complitionDate,
            developer: req.body.developer,
            project: req.body.project,
            time: req.body.time,
            status: 'Incomplete'
        }, (err, task) => {
            if (err) return res.send(err);
            return res.send(task);
        });
    },
    // to get all
    getAllTask: (req: Request, res: Response) => {
        Task.find({
            isDeleted: false
        }).populate('project').populate('developer').exec((err, task) => {
            if (err) return res.send(err);
            return res.send(task);
        });
    },
    // to get all task for project
    getAllTaskByProject: (req: Request, res: Response) => {
        Task.find({
            project: req.params.id, isDeleted: false
        }).populate('project').populate('developer').exec((err, task) => {
            if (err) return res.send(err);
            return res.send(task);
        });
    },
    
    // to get all task for developer
    getAllTaskByDeveloper: (req: Request, res: Response) => {
        Task.find({
            developer: req.params.id, isDeleted: false  
        }).populate('project').populate('developer').exec((err, task) => {
            if (err) return res.send(err);
            return res.send(task);
        });
    },
    //
    getAllTaskByProjectByDeveloper: (req: Request, res: Response) => {
        //console.log(req.query.dev);
        //console.log(req.query.pro);
        // Task.find({
        //     project: req.params.id, isDeleted: false
        // }).populate('project').populate('developer').exec((err, task) => {
        //     if (err) return res.send(err);
        //     return res.send(task);
        // });
        res.send('dd');
    },
    //
    updateTask: (req: Request, res: Response) => {
        let task = req.body;
        Task.findById(task._id, (err, dbtask) => {
            if (err) return res.send(err);
            //
            dbtask.title = task.title;
            dbtask.description = task.description;
            dbtask.complitionDate = task.complitionDate;
            dbtask.developer = task.developer._id;
            dbtask.time = task.time;
            dbtask.status = task.status;
            dbtask.save();
            return res.send(dbtask);
        });
    },
    deleteTask: (req: Request, res: Response) => {
        Task.findById(req.params.id, (err, task) => {
            task.isDeleted = true;
            task.save();
            return res.send(task);
        });
    },
}
export =  taskController;