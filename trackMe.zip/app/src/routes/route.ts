//<reference path="../typings/node/node.d.ts" />
import home = require('../controller/homeController');
import login = require('../controller/loginController');
import developer = require('../controller/developerController');
import project = require('../controller/projectController');
import Task = require('../controller/taskController');


import express = require('express');

let router: express.Router = express.Router();

//home controller routes 
router.get('/', home.getIndex);

//login controller routes
router.post('/login', login.login);

//developer controller routes
router.post('/register', developer.registerDeveloper);
router.get('/developer/:id', developer.getUser);
router.get('/developer', developer.getDeveloper);

//project controller routes
router.get('/project/:id', project.getProject);
router.get('/project', project.getAllProject);
router.post('/project', project.post);
router.put('/project', project.put);
router.delete('/project', project.delete);


//task controller routes
router.post('/task', Task.newTask);
router.get('/task', Task.getAllTask);
router.get('/task/p/:id', Task.getAllTaskByProject);
router.get('/task/d/:id', Task.getAllTaskByDeveloper);
router.get('/task/test', Task.getAllTaskByProjectByDeveloper);
router.put('/task', Task.updateTask);
router.delete('/task/:id', Task.deleteTask);




module.exports = router;


