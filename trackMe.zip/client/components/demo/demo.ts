import { Component, View, Inject} from 'angular2/core';
import { CORE_DIRECTIVES } from 'angular2/common';
import { TAB_COMPONENTS } from 'ng2-bootstrap/ng2-bootstrap';

// webpack html imports
@View({
    templateUrl: '/scripts/src/components/demo/demo.html',
    directives:[TAB_COMPONENTS, CORE_DIRECTIVES]
})
@Component({
  selector: 'tabs-demo',
})
export class DemoComponent {
 
}

