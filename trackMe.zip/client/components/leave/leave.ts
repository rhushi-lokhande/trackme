import {Component, View} from 'angular2/core';
//
import { TAB_COMPONENTS } from 'ng2-bootstrap/ng2-bootstrap';
//
@Component({
    selector: 'leave',

})
@View({
    templateUrl: './scripts/src/components/leave/leave.html',
    directives: [TAB_COMPONENTS]
})
export class LeaveComponent {

}
