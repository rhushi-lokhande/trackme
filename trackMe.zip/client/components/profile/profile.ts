import {Component, View} from 'angular2/core';
@Component({
  selector: 'profile'
})
@View({
  templateUrl: '/scripts/src/components/profile/profile.html',
})
export class ProfileComponent {
    
}
