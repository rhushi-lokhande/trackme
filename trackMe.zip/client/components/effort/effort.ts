import {Component, View, Inject} from 'angular2/core';
import {NgFor} from 'angular2/common';
import {ProjectService} from '../../services/projectService'
import {TaskService} from '../../services/taskService'
//
import { TAB_COMPONENTS } from 'ng2-bootstrap/ng2-bootstrap';
//
import {GlobalDataService} from '../../services/globalDataService';
//
import {LoginComponent} from '../login/login';
@Component({
    selector: 'effort',
    providers: [ProjectService, TaskService]
})
@View({
    templateUrl: '/scripts/src/components/effort/effort.html',
    directives: [NgFor, TAB_COMPONENTS, LoginComponent]
})
export class EffortComponent {
    projects: {};
    newTask: {
        project: string,
        developer: string,
        title: string,
        description: string;
        complitionDate: Date;
        time: number
    };
    tasks: any;
    globalDataService: any;
    constructor(
        @Inject(ProjectService) private projectService: ProjectService,
        @Inject(TaskService) private taskService: TaskService
    ) {
        this.tasks = [];
        this.globalDataService = GlobalDataService;
        this.projectService.get((res) => {
            this.projects = res;
            this.getTaskByProject(this.projects[0]._id);
        }, (e) => { });
        this.setTask();
    }
    setTask() {
        this.newTask = {
            project: "",
            developer: "",
            title: "",
            description: "",
            complitionDate: null,
            time: null
        };
    }
    addTask() {
        this.newTask.developer = this.globalDataService.dev._id;
        this.taskService.post(this.newTask, (res) => {
            console.log(res);
            this.setTask();
        }, (e) => { });
    }
    getTaskByProject(project) {
        this.taskService.getTaskByProject(project, (res) => {
            this.tasks = res;
        }, (e) => { });
    }
    completeTask(task, project: string) {
        task.status='Complete';
        this.taskService.updateTask(task, (res) => {
            this.getTaskByProject(project);
        }, (e) => { });
    }
}
