import {Component, View} from 'angular2/core';
@Component({
  selector: 'home'
})
@View({
  templateUrl: '/scripts/src/components/home/home.html',
})
export class HomeComponent {
}
