/// <reference path="express/express.d.ts" />
/// <reference path="gulp/gulp.d.ts" />
/// <reference path="serve-static/serve-static.d.ts" />
/// <reference path="morgan/morgan.d.ts" />
/// <reference path="cookie-parser/cookie-parser.d.ts" />
/// <reference path="body-parser/body-parser.d.ts" />
/// <reference path="angular2/angular2.d.ts" />
/// <reference path="mongoose/mongoose.d.ts" />
