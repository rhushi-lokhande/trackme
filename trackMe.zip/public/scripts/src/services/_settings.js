var baseUrl = '/api';
exports._Settings = {
    baseUrl: baseUrl,
    url: {
        login: baseUrl + '/login',
        developer: baseUrl + '/developer',
        project: baseUrl + '/project',
        task: baseUrl + '/task',
        taskByDeveloper: baseUrl + '/task/d',
        taskByProject: baseUrl + '/task/p',
        updatetask: baseUrl + '/task'
    }
};

//# sourceMappingURL=../../map/services/_settings.js.map
